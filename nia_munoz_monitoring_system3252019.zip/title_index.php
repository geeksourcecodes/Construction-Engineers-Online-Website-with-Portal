				
								<div class="row-fluid">

						<div class="span12">
						
						</div>	
													
							</div>
							<div class="row-fluid">

						<div class="span4">
						<img class="index_logo" src="admin/images/NIA.png">
						</div>	
						<div class="span8">
						
								<div class="title">
							<p class="chmsc"></p>
							<h3>

							<p></p>
						
							</h3>		
						</div>
			
						</div>							
							</div>
				
				<div class="row-fluid">

						<div class="span12">
						<br>
								<div class="motto">
												<!-- <p>National Irrigation Administration</p>
												<p>DIVISION OFFICE, SCIENCE CITY OF MUNOZ</p>
												<p>PROJECT MONITORING SYSTEM</p> -->
											<p>	Engineer's Portal</p>
											
								</div>		
						</div>		
				</div>