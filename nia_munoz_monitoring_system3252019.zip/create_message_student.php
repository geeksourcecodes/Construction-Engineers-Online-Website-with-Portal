<style type="text/css">
    .dot{
  height: 15px;
  width: 15px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
}
    .dot-green{
  height: 15px;
  width: 15px;
  background-color: #33ff33;
  border-radius: 50%;
  display: inline-block;

}
</style>
<div class="span3" id="">
	<div class="row-fluid">

				      <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div id="" class="muted pull-left"><h4><i class="icon-pencil"></i> Create Message</h4></div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
								
								    <ul class="nav nav-tabs">
										<li class="active">
											<a href="student_message.php">Engineer</a>
										</li>
										<li><a href="student_message_student.php"></a></li>
									</ul>
								
								
	

								<form method="post" id="send_message">
										<div class="control-group">
											<label>To:</label>
                                          <div class="controls">
                                            <select name="teacher_id" class="chzn-select" required>
                                              	<option></option>
											<?php
											$query = mysql_query("select * from teacher order by firstname");
											while($row = mysql_fetch_array($query)){

													if ($row['status_line']==0) {
                                      			  # code...
			                                        $status_line = "<span class='dot'></span>Offline";
			                                    }else{
			                                        $status_line="<span class='dot-green'></span>Online"; 
			                                    }
											
											?>
											
											<option value="<?php echo $row['teacher_id']; ?>"><?php echo $row['firstname']; ?> <?php echo $row['lastname']. ' | ' . $status_line; ?> </option>
											
											<?php } ?>
                                            </select>
                                          </div>
                                        </div>
								
							
										<div class="control-group">
											<label>Content:</label>
                                          <div class="controls">
											<textarea name="my_message" class="my_message" required></textarea>
                                          </div>
                                        </div>
										<div class="control-group">
                                          <div class="controls">
												<button  class="btn btn-success"><i class="icon-envelope-alt"></i> Send </button>

                                          </div>
                                        </div>
                                </form>

					
								
								
							
								
								
										<script>
			jQuery(document).ready(function(){
			jQuery("#send_message").submit(function(e){
					e.preventDefault();
					var formData = jQuery(this).serialize();
					$.ajax({
						type: "POST",
						url: "send_message_student.php",
						data: formData,
						success: function(html){
						
						$.jGrowl("Message Successfully Sended", { header: 'Message Sent' });
						var delay = 2000;
							setTimeout(function(){ window.location = 'student_message.php'  }, delay);  
						
						
						}
						
					});
					return false;
				});
			});
			</script>
			
			
							
								
								</div>
                            </div>
                        </div>
                        <!-- /block -->
						

	</div>
</div>