<?php 
session_start();
include('dbcon.php');
$sql = "UPDATE `teacher` SET `status_line`=0 WHERE `teacher_id`=".$_SESSION['id'];
mysql_query($sql);


session_destroy();
header('location:index.php');

?>