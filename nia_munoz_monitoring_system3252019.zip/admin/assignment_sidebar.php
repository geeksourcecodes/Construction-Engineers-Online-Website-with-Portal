		 <div class="span3" id="sidebar">
						<ul class="nav nav-list bs-docs-sidenav nav-collapse collapse">
							<li> <a href="dashboard.php"><i class="icon-chevron-right"></i><i class="icon-home"></i>&nbsp;Dashboard</a> </li>
							
							<li>
								<a href="admin_user.php"><i class="icon-chevron-right"></i><i class="icon-user"></i> Admin Users</a>
							</li>
							
							<li>
								<a href="students.php"><i class="icon-chevron-right"></i><i class="icon-group"></i> NIA Office</a>
							</li>
							<li>
								<a href="teachers.php"><i class="icon-chevron-right"></i><i class="icon-group"></i> Engineers</a>
							</li>
							<li>
								<a href="downloadable.php"><i class="icon-chevron-right"></i><i class="icon-download"></i> Downloadable Materials</a>
							</li>
							
							
							<li>
								<a href="user_log.php"><i class="icon-chevron-right"></i><i class="icon-file"></i> User Log</a>
							</li>
							<li>
								<a href="activity_log.php"><i class="icon-chevron-right"></i><i class="icon-file"></i> Activity Log</a>
							</li>
							
						</ul>
						
						
					
					</div>