<div class="pull-right">
		<footer>
           <p>Programmed by: Team RRJ</p>
        <footer>
</div>